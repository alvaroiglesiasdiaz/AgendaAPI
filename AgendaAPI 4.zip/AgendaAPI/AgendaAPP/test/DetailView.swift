//
//  DetailView.swift
//  ListView
//
//  Created by user177270 on 10/18/20.
//  Copyright © 2020 CEV. All rights reserved.
//

import UIKit

class DetailView: UIViewController {
    
    var titleText: String?
    var movieImg: UIImage?
    var sinopsisText: String?
    
    @IBOutlet weak var imageDetail: UIImageView!
    
    @IBOutlet weak var titleDetail: UILabel!
    
    @IBOutlet weak var sinopsisDetail: UILabel!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let titleText = titleText {
            titleDetail.text = titleText
            
        }
        if let movieTitle = movieImg {
            imageDetail.image = movieImg
            
        }
        if let sinopsisText = sinopsisText {
            sinopsisDetail.text = sinopsisText
            
        }
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
