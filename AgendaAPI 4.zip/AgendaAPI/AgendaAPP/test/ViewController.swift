//
//  ViewController.swift
//  ListView
//
//  Created by Apps2t on 09/10/2020.
//  Copyright © 2020 CEV. All rights reserved.
//

import UIKit




class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet var tableView: UITableView!

    
    let image = [
        UIImage(named: "Goodfellas"),
        UIImage(named: "Inception"),
        UIImage(named: "The Lighthouse"),
        UIImage(named: "Jurassic Park"),
        UIImage(named: "Sin City"),
        UIImage(named: "Midsommar"),
        UIImage(named: "Gran Torino"),
        UIImage(named: "Scarface")
    ]
    var myIndex = 0
    let movies = ["Goodfellas",
                  "Inception",
                  "The Lighthouse",
                  "Jurassic Park",
                  "Sin City",
                  "Midsommar",
                  "Gran Torino",
                  "Scarface"]
    let sinopsis = ["Henry Hill, hijo de padre irlandés y madre siciliana, vive en Brooklyn y se                  siente fascinado por la vida que llevan los gángsters de su barrio, donde la                 mayoría de los vecinos son inmigrantes. Paul Cicero, el patriarca de la                      familia Pauline, es el protector del barrio. A los trece años, Henry decide                  abandonar la escuela y entrar a formar parte de la organización mafiosa como                 chico de los recados; muy pronto se gana la confianza de sus jefes, gracias a                lo cual irá subiendo de categoría.",
                    "Dom Cobb (DiCaprio) es un experto en el arte de apropiarse, durante el sueño, de los secretos del subconsciente ajeno. La extraña habilidad de Cobb le ha convertido en un hombre muy cotizado en el mundo del espionaje, pero también lo ha condenado a ser un fugitivo y, por consiguiente, a renunciar a llevar una vida normal. Su única oportunidad para cambiar de vida será hacer exactamente lo contrario de lo que ha hecho siempre: la incepción, que consiste en implantar una idea en el subconsciente en lugar de sustraerla. Sin embargo, su plan se complica debido a la intervención de alguien que parece predecir cada uno de sus movimientos, alguien a quien sólo Cobb podrá descubrir.",
                    
                    "Una remota y misteriosa isla de Nueva Inglaterra en la década de 1890. El veterano farero Thomas Wake (Willem Dafoe) y su joven ayudante Ephraim Winslow (Robert Pattinson) deberán convivir durante cuatro semanas. Su objetivo será mantener el faro en buenas condiciones hasta que llegue el relevo que les permita volver a tierra. Pero las cosas se complicarán cuando surjan conflictos por jerarquías de poder entre ambos.",
                    "John Hammond, magnate propietario de la empresa multinacional en bioingeniería InGen, ha soñado toda su vida con construir el mayor parque de atracciones del mundo. Una isla en Costa Rica donde habiten las criaturas más espectaculares que han pisado la Tierra: los dinosaurios. Pese a la extinción de estos reptiles, InGen ha logrado clonar diversas especies mediante la manipulación de segmentos de ADN de la propia sangre de dinosaurio, encontrada en mosquitos fosilizados en ámbar.",
                    "En Sin City, ciudad de policías corruptos y atractivas mujeres, unos buscan venganza, otros, redención, o ambas cosas a la vez. Marv (Mickey Rourke) se propone vengar la muerte de su único amor. Dwight (Clive Owen) es un investigador privado con problemas que resolver. Hartigan (Bruce Willis), el único policía honrado de la ciudad, sigue la pista de una joven que está en manos del sádico hijo de un senador.",
                    "Una pareja estadounidense que no está pasando por su mejor momento acude con unos amigos al Midsommar, un festival de verano que se celebra cada 90 años en una aldea remota de Suecia. Lo que comienza como unas vacaciones de ensueño en un lugar en el que el sol no se pone nunca, poco a poco se convierte en una oscura pesadilla cuando los misteriosos aldeanos les invitan a participar en sus perturbadoras actividades festivas.",
                    "Walt Kowalski (Clint Eastwood), un veterano de la guerra de Corea (1950-1953), es un obrero jubilado del sector del automóvil que ha enviudado recientemente. Su máxima pasión es cuidar de su más preciado tesoro: un coche Gran Torino de 1972. Es un hombre inflexible y cascarrabias, al que le cuesta trabajo asimilar los cambios que se producen a su alrededor, especialmente la llegada de multitud de inmigrantes asiáticos a su barrio. Sin embargo, las circustancias harán que se vea obligado a replantearse sus ideas. ",
                    "Tony Montana es un emigrante cubano frío e implacable que se instala en Miami con el propósito de convertirse en un gángster importante, y poder así ganar dinero y posición. Con la colaboración de su amigo Manny Rivera inicia una fulgurante carrera delictiva, como traficante de cocaína, con el objetivo de acceder a la cúpula de una organización de narcos."
    ]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell"/*, for: indexPath*/) as! CumtomCell
        
        cell.movieImage.image = self.image[indexPath.row]
        cell.movieTitleLB.text = movies[indexPath.row]
        //cell.textLabel?.text = movies[indexPath.row]
        //cell.imageView?.image = image[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //tableView.deselectRow(at: indexPath, animated: true)
        myIndex = indexPath.row
        performSegue(withIdentifier: "segue", sender: self)
        
       
        
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {

        return 1

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segue"{
            
            if let indexPath = tableView.indexPathForSelectedRow{
                
                let destinationVC = segue.destination as!  DetailView
                destinationVC.titleText = movies[indexPath.row]
                destinationVC.movieImg = image[indexPath.row]
                destinationVC.sinopsisText = sinopsis[indexPath.row]
            }
        }
            
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        
    }


}

