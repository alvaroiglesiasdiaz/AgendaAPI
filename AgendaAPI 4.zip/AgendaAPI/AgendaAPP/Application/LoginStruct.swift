//
//  LoginStruct.swift
//  AgendaAPP
//
//  Created by user177270 on 3/11/21.
//

import Foundation

struct loginToken: Decodable {
    
    let token: String
    
}
