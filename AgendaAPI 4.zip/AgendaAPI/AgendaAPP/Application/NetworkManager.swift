//
//  NetworkManager.swift
//  AgendaAPP
//
//  Created by Apps2t on 02/03/2021.
//
// h ttps://www.youtube.com/watch?v=OQ6wm1QQPWA
import Foundation
import Alamofire

class NetworkManager {
    
    static var shared: NetworkManager = NetworkManager()
    var apiToken: Any?
    var data:[Contact] = []
    var contactArray: Any = []
    
    //Funcion loguear usuario
    func userLogin(email: String, password: String,completionHandler: @escaping(Bool)-> Void){
        
        struct Login: Encodable{
            
            public let email: String
            public let password: String
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let loginParams: [String:Any] = ["email": email , "password": password]
        print(loginParams)
        let loginRequest = try? JSONSerialization.data(withJSONObject: loginParams)
        //Create Alamofire request to API
    
        var requestLogin = URLRequest(url: url)
        requestLogin.httpMethod = "GET"
        requestLogin.httpBody = loginRequest
        requestLogin.headers = ["Content-Type": "application/json"]
        
        AF.request(requestLogin).responseJSON{response in

            debugPrint(response)
            debugPrint("Login request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Login error")
                completionHandler(false)

            }
        }
    }
    //Registrar un nuevo usuario a la app
    func userRegister(email: String, password: String, repeatPass: String,completionHandler: @escaping(Bool)-> Void){
        
        struct Register: Encodable{
            
            public let email: String
            public let password: String
            public let repeatPass: String
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let registerParams: [String:Any] = ["email": email , "password": password, "repeatPass": repeatPass]
        print(registerParams)
        let registerRequest = try? JSONSerialization.data(withJSONObject: registerParams)
        
        //Create Alamofire request to API
    
        var requestRegister = URLRequest(url: url)
        requestRegister.httpMethod = "POST"
        requestRegister.httpBody = registerRequest
        requestRegister.headers = ["Content-Type": "application/json"]
        
        AF.request(requestRegister).responseJSON{response in

            debugPrint(response)
            debugPrint("Register request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Register error")
                completionHandler(false)

            }
        }
    }
    //Se envia el email y si coincide con el de la base de datos se envia un email al usuario con la contrasena
    func passRecover(email: String,completionHandler: @escaping(Bool)-> Void){
        
        struct Recover: Encodable{
            
            public let email: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let recoverParams: [String:Any] = ["email": email ]
        print(recoverParams)
        let recoverRequest = try? JSONSerialization.data(withJSONObject: recoverParams)
        
        //Create Alamofire request to API
    
        var requestRecover = URLRequest(url: url)
        requestRecover.httpMethod = "GET"
        requestRecover.httpBody = recoverRequest
        requestRecover.headers = ["Content-Type": "application/json"]
        
        AF.request(requestRecover).responseJSON{response in

            debugPrint(response)
            debugPrint("Recover password request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Recover password error")
                completionHandler(false)

            }
        }
        
    }
    
    //Se imprime una lista con todos los contactos para poder mostrarlos en la tabla
    func contactList(email: String, completionHandler: @escaping(Bool)-> Void){
        
        
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        
        //Create Alamofire request to API
    
        var requestList = URLRequest(url: url)
        requestList.httpMethod = "GET"
        requestList.headers = ["Content-Type": "application/json"]
        
        AF.request(requestList).responseJSON{response in

            debugPrint(response)
            debugPrint("Contact list request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Contact list error")
                completionHandler(false)

            }
        }
    }
  
    //Funcion para anadir nuevo contacto del usuario
    func addUser(name: String,completionHandler: @escaping(Bool)-> Void){
        
        struct Add: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let createParams: [String:Any] = ["name": name ]
        print(createParams)
        let createRequest = try? JSONSerialization.data(withJSONObject: createParams)
        
        //Create Alamofire request to API
    
        var requestCreate = URLRequest(url: url)
        requestCreate.httpMethod = "POST"
        requestCreate.httpBody = createRequest
        requestCreate.headers = ["Content-Type": "application/json"]
        
        AF.request(requestCreate).responseJSON{response in

            debugPrint(response)
            debugPrint("Create contact request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Create contact error")
                completionHandler(false)

            }
        }
    }
    //Edit nombre del contacto seleccionado
    func editUser(name: String,email: String,completionHandler: @escaping(Bool)-> Void){
        
        struct Add: Encodable{
            
            public let name: String
            public let email: String

        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let editParams: [String:Any] = ["name": name,"email": email ]
        print(editParams)
        let editRequest = try? JSONSerialization.data(withJSONObject: editParams)
        
        //Create Alamofire request to API
    
        var requestEdit = URLRequest(url: url)
        requestEdit.httpMethod = "POST"
        requestEdit.httpBody = editRequest
        requestEdit.headers = ["Content-Type": "application/json"]
        
        AF.request(requestEdit).responseJSON{response in

            debugPrint(response)
            debugPrint("Edit contact request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Edit contact error")
                completionHandler(false)

            }
        }
    }
    //Se borra el contacto seleccionado de la lista
    func deleteAccount(name: String,completionHandler: @escaping(Bool)-> Void){
        
        struct Recover: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let recoverParams: [String:Any] = ["name": name ]
        print(recoverParams)
        let recoverRequest = try? JSONSerialization.data(withJSONObject: recoverParams)
        
        //Create Alamofire request to API
    
        var requestDelete = URLRequest(url: url)
        requestDelete.httpMethod = "GET"
        requestDelete.httpBody = recoverRequest
        requestDelete.headers = ["Content-Type": "application/json"]
        
        AF.request(requestDelete).responseJSON{response in

            debugPrint(response)
            debugPrint("Delete account request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Delete account error")
                completionHandler(false)

            }
        }
    }
    
    func editPassword(password: String,completionHandler: @escaping(Bool)-> Void){
        
        struct Add: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let editParams: [String:Any] = ["password": password ]
        print(editParams)
        let editRequest = try? JSONSerialization.data(withJSONObject: editParams)
        
        //Create Alamofire request to API
    
        var requestEdit = URLRequest(url: url)
        requestEdit.httpMethod = "POST"
        requestEdit.httpBody = editRequest
        requestEdit.headers = ["Content-Type": "application/json"]
        
        AF.request(requestEdit).responseJSON{response in

            debugPrint(response)
            debugPrint("Edit password request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Edit password error")
                completionHandler(false)

            }
        }
    }
    //Se borra el contacto seleccionado de la lista
    func deleteProfile(name: String,completionHandler: @escaping(Bool)-> Void){
        
        struct Recover: Encodable{
            
            public let name: String
           
        }
        //API url
        //URL de prueba para comprobar que la peticion funciona
        let url = URL(string: "https://api.backendless.com/application-id/REST-api-key/users/login")!
        let recoverParams: [String:Any] = ["name": name ]
        print(recoverParams)
        let recoverRequest = try? JSONSerialization.data(withJSONObject: recoverParams)
        
        //Create Alamofire request to API
    
        var requestDelete = URLRequest(url: url)
        requestDelete.httpMethod = "GET"
        requestDelete.httpBody = recoverRequest
        requestDelete.headers = ["Content-Type": "application/json"]
        
        AF.request(requestDelete).responseJSON{response in

            debugPrint(response)
            debugPrint("Delete contact request")
            switch response.result{
            case .success:
                let value = response.result as! [String: Any]
                completionHandler(true)

            case .failure(let error):
                print(error)
                print("Delete contact error")
                completionHandler(false)

            }
        }
    }
}

