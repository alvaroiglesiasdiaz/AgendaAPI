//
//  CustomCell.swift
//  AgendaAPP
//
//  Created by Apps2t on 02/03/2021.
//

import UIKit

class SettingCell: UITableViewCell {

    @IBOutlet weak var customView: UIView!
    @IBOutlet weak var LBSettingName: UILabel!
    
   

    /* @IBOutlet weak var movieImage: UIImageView!
    
    @IBOutlet weak var movieTitleLB: UILabel!*/
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
