//
//  RecoverPassViewController.swift
//  AgendaAPP
//
//  Created by user177270 on 3/7/21.
//

import UIKit

class RecoverPassViewController: UIViewController{
  
    @IBOutlet weak var TFEmail: UITextField!
    @IBOutlet weak var BTNRecoverOutlet: UIButton!
    @IBAction func BTNRecover(_ sender: Any) {
    
    
    if (TFEmail?.text == ""){
                   showAlertEmpty()
               }
        
        else{
         //   NetworkManager.shared.passRecover(email: TFEmail.text!)

                   performSegue(withIdentifier: "recoverToLogin", sender: self)
               }
        
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Set circular corners
        //BTNLogin.layer.cornerRadius = 20.0
        BTNRecoverOutlet.layer.cornerRadius = 25.0
      //  TFEmail?.layer.borderColor = UIColor(red: 249/255, green: 120/255, blue: 88/225, alpha: 1).cgColor
       TFEmail?.layer.cornerRadius = 10.0
     //   TFEmail?.layer.borderWidth = 2
       
        
    }

    
    func showAlertEmpty(){
            //la variable alert va a mostrar un dialogo en pantalla y toma 3 argumentos, el titulo. la descripcion y el estilo
            let alert = UIAlertController(title: "Recover failed", message: "Email incorrect or missing, please try again", preferredStyle: .alert)
            //aqui añado las acciones que  van a tener ambos botones del alert como variables
            let ok = UIAlertAction(title: "OK", style: .default, handler: { (action) -> Void in
            })
            
            alert.addAction(ok)
            self.present(alert, animated: true, completion: nil)
            
        }
}

