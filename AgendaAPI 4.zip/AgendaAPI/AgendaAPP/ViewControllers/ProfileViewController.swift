//
//  SettingsViewController.swift
//  AgendaAPP
//
//  Created by Apps2t on 03/03/2021.
//

import UIKit
import Firebase
import FirebaseAuth
class ProfileViewController: UIViewController {
    
    
    
    @IBOutlet weak var LBNameUser: UILabel!
    @IBOutlet weak var LBEmailUser: UILabel!
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    @IBAction func BTNDeleteContact(_ sender: Any) {
        spinner.isHidden = false
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        spinner.backgroundColor = .black
        spinner.color = .white
        NetworkManager.shared.deleteAccount(name: LBNameUser.text!, completionHandler: { [self]
            success in
            
            print("Create contact request sent")
            
            if success{
                
                print("Create contact success")
                
                //Ejecutar segue de manera sincrona
                DispatchQueue.global().sync {
                    do{
                        
                        //delete user
                    }catch {
                        
                        }
                }
                
            }else{
                
                print("Request error")
                //If request fails then show alert
                self.present(Helper.showAlertController(title: "Profile succesfully deleted", message: "OK"), animated: true, completion: nil)
                
                spinner.stopAnimating()
                spinner.isHidden = true
            }
        })
    }
    @IBAction func BTNChangePassword(_ sender: Any) {
        spinner.isHidden = false
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        spinner.backgroundColor = .black
        spinner.color = .white
        showAlertEdit()
    }
    @IBAction func BTNSignOut(_ sender: Any) {
        spinner.isHidden = false
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        spinner.backgroundColor = .black
        spinner.color = .white
        let auth = Auth.auth()
        
        do{
            try auth.signOut()
            let defaults = UserDefaults.standard
            defaults.set(false, forKey: "isUserSignIn")
            self.dismiss(animated: true, completion: nil)
            spinner.stopAnimating()
            spinner.isHidden = true
        }catch let signoutError {
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        spinner.isHidden = true
        let defaults = UserDefaults.standard
        guard let uid = Auth.auth().currentUser?.uid else {
                    print("Usuario no encontrado")
                    return
                }
        Helper.getUserInfo(onSuccess: {
            
            let username = defaults.string(forKey: "userNameKey")
            let email = defaults.string(forKey: "userEmailKey")
            self.LBNameUser.text = "Welcome " + username!
            self.LBEmailUser.text = email!
            
        }, onError: { (error) in
            self.present(Helper.showAlertController(title: "Error", message: "Could not retrieve user data"), animated: true, completion: nil)
        })

        }
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
              
             
              }
    
    
    func showAlertEdit(){
            //la variable alert va a mostrar un dialogo en pantalla
            let alert = UIAlertController(title: "Change password", message: "Set a new  password", preferredStyle: .alert)
            
        let action = UIAlertAction(title: "Change password", style: .default) { (alertAction) in
          let textField = alert.textFields![0] as UITextField
        
            if(textField.text != ""){
               
                NetworkManager.shared.editPassword(password: textField.text!, completionHandler: { [self]
                    success in
                    
                    print("Create contact request sent")
                    
                    if success{
                        
                        print("Create contact success")
                        
                        //Ejecutar segue de manera sincrona
                        DispatchQueue.global().sync {
                            do{
                                
                                //edit user password
                            }catch {
                                
                                }
                        }
                        
                    }else{
                        
                        print("Request error")
                        //If request fails then show alert
                        spinner.stopAnimating()
                        spinner.isHidden = true
                        self.present(Helper.showAlertController(title: "Password succesfully changed", message: "OK"), animated: true, completion: nil)
                        
                        
                    }
                })
                
            }
        
        }
        alert.addTextField { (textField) in
        textField.placeholder = "Enter new password"
        }
        
        alert.addAction(action)
        spinner.stopAnimating()
        spinner.isHidden = true
        self.present(alert, animated: true, completion: nil)
        }
    
    }
