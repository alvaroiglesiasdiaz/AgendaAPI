//
//  ViewController.swift
//  AgendaAPP
//
//  Created by user177270 on 3/1/21.
//

import UIKit
import  Firebase
import  FirebaseAuth

class LoginViewController: UIViewController{
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    @IBOutlet weak var BTNLoginOutlet: UIButton!
    @IBOutlet weak var TFEmail: UITextField?
    @IBOutlet weak var TFPassword: UITextField?
    @IBAction func BTNLogin(_ sender: Any) {
        spinner.isHidden = false
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        spinner.backgroundColor = .black
        spinner.color = .white
        if (TFEmail?.text == "" || TFPassword?.text == ""){
            
           present( Helper.showAlertController(title: "Login failed", message: "Email or password incorrect or missing, please try again"), animated: true, completion: nil)}else{
            
           // let activityIndicator = UIActivityIndicatorView() // Create the activity indicator
            //view.addSubview(activityIndicator) // add it as a  subview
            //activityIndicator.startAnimating()
           NetworkManager.shared.userLogin(email: (TFEmail?.text)!, password: (TFPassword?.text)!, completionHandler: { [self]
                success in
                
                print("Login request sent")
                
                if success{
                    
                    print("Login success")
                    
                    //Ejecutar segue de manera sincrona
                    DispatchQueue.global().sync {
                        do{
                            let defaults = UserDefaults.standard
                            
                            let token = defaults.object(forKey: "token")!
                            
                            print ("User token: ",token)
                            
                            let dataToken = defaults.string(forKey: "token")
                            //Segue to contact list view

                        }catch {
                            
                            }
                    }
                    
                }else{
                    
                    print("Request error")
                    //If login fails then show alert
                    spinner.stopAnimating()
                    spinner.isHidden = true
                    self.present(Helper.showAlertController(title: "Failed Request", message: "Code 404"), animated: true, completion: nil)
                
                }
            })
             
            let auth = Auth.auth()
            
            auth.signIn(withEmail: TFEmail!.text!, password: TFPassword!.text!){ [self] (authResult, error) in
                
                if error != nil{
                    self.present(Helper.showAlertController(title: "Error", message: "There was an error trying to log in"), animated: true, completion: nil)
                   

                    return

                
            }
        }
            self.performSegue(withIdentifier: "loginToList", sender: self)


           }}
   
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        spinner.isHidden = true

        //Set circular corners
        BTNLoginOutlet.layer.cornerRadius = 25.0
        //TFEmail?.layer.borderColor = UIColor(red: 249/255, green: 120/255, blue: 88/225, alpha: 1).cgColor
        TFEmail?.layer.cornerRadius = 10.0
        //TFEmail?.layer.borderWidth = 2
        TFPassword?.layer.cornerRadius = 10.0
        //TFPassword?.layer.borderColor = UIColor(red: 249/255, green: 120/255, blue: 88/225, alpha: 1).cgColor
        //TFPassword?.layer.borderWidth = 2
        
    }

}

