//
//  RegisterViewController.swift
//  AgendaAPP
//
//  Created by user177270 on 3/7/21.
//

import UIKit
import Firebase
import FirebaseAuth
class RegisterViewController: UIViewController{
  
    @IBOutlet weak var TFEmail: UITextField!
    @IBOutlet weak var BTNRegister: UIButton!
    @IBOutlet weak var TFUser: UITextField!
    
    @IBOutlet weak var TFPassword: UITextField!
    @IBOutlet weak var TFRepeatPass: UITextField!
    
    @IBAction func BTNResgiter(_ sender: Any) {
        if (TFEmail?.text == "" || TFPassword?.text == "" || TFRepeatPass?.text == nil){
                   
           present( Helper.showAlertController(title: "Registration failed", message: "Email or password incorrect or missing, please try again"), animated: true, completion: nil)
        }
        if (TFPassword.text != TFRepeatPass.text) {
            present(Helper.showAlertController(title: "Credentials error", message: "Passwords do not match"), animated: true, completion: nil)
            
        }
        else{
          //NetworkManager.shared.userRegister(email: TFEmail.text!, password: TFPassword.text!, repeatPass: TFRepeatPass.text!)
            Helper.signUpUser(email: TFEmail.text!, password: TFPassword.text!, name: TFUser.text!, onSuccess: {
                self.performSegue(withIdentifier: "registerToLogin", sender: self)
            }) {(error) in
            Helper.showAlertController(title: "Credentials error", message: "Passwords do not match")


        }}
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Set circular corners
        BTNRegister.layer.cornerRadius = 25.0
       // TFEmail?.layer.borderColor = UIColor(red: 249/255, green: 120/255, blue: 88/225, alpha: 1).cgColor
        TFEmail?.layer.cornerRadius = 10.0
       // TFEmail?.layer.borderWidth = 2
       TFPassword?.layer.cornerRadius = 10.0
      //  TFPassword?.layer.borderColor = UIColor(red: 249/255, green: 120/255, blue: 88/225, alpha: 1).cgColor
      //  TFPassword?.layer.borderWidth = 2

        
        }
    

    
    
}


