//
//  SettingsViewController.swift
//  AgendaAPP
//
//  Created by Apps2t on 03/03/2021.
//

import UIKit

class SettingsViewController: UIViewController {
    
    @IBOutlet weak var spinner: UIActivityIndicatorView!

    @IBOutlet weak var LBContactName: UILabel!
    var contactName: String?
    
    @IBAction func BTNDeleteContact(_ sender: Any) {
        spinner.isHidden = false
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        spinner.backgroundColor = .black
        spinner.color = .white

        NetworkManager.shared.deleteProfile(name: LBContactName.text!, completionHandler: { [self]
            success in
            
            print("Delete contact request sent")
            
            if success{
                
                print("Delete contact success")
                
                //Ejecutar segue de manera sincrona
                DispatchQueue.global().sync {
                    do{
                        
                        //delete user
                    }catch {
                        
                        }
                }
                
            }else{
                
                print("Request error")
                //If request fails then show alert
                self.present(Helper.showAlertController(title: "Contact succesfully deleted", message: "OK"), animated: true, completion: nil)
                
                spinner.stopAnimating()
                spinner.isHidden = true
            }
        })    }
    @IBAction func BTNModifyContact(_ sender: Any) {
        spinner.isHidden = false
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        spinner.backgroundColor = .black
        spinner.color = .white
        self.performSegue(withIdentifier: "settingsToEdit", sender: self)

    }
    override func viewDidLoad() {
           super.viewDidLoad()
        spinner.isHidden = true

              
        
       }
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        spinner.isHidden = true

              if let contactName = contactName {
                  LBContactName.text = contactName
                  
              }
    }
    
    
    
    }
