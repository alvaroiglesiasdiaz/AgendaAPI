//
//  Service.swift
//  AgendaAPP
//
//  Created by user177270 on 3/18/21.
//

import UIKit

class Service: super class {
    <#code#>
}
