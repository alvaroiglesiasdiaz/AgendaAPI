//
//  EditProfileViewController.swift
//  AgendaAPP
//
//  Created by user177270 on 3/22/21.
//

import UIKit

class EditProfileViewController: UIViewController {
    @IBOutlet weak var TFEmail: UITextField!
    @IBOutlet weak var TFName: UITextField!
    
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    @IBOutlet weak var BTNEditStyle: UIButton!
    @IBAction func BTNEdit(_ sender: Any) {
        spinner.isHidden = false
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        spinner.backgroundColor = .black
        spinner.color = .white
        if (TFEmail?.text == "" || TFName?.text == ""){
            
           present( Helper.showAlertController(title: "Login failed", message: "Email or password incorrect or missing, please try again"), animated: true, completion: nil)}else{
            
           // let activityIndicator = UIActivityIndicatorView() // Create the activity indicator
            //view.addSubview(activityIndicator) // add it as a  subview
            //activityIndicator.startAnimating()
           NetworkManager.shared.editUser(name: (TFName?.text)!, email: (TFEmail?.text)!, completionHandler: { [self]
                success in
                
                print("Edit request sent")
                
                if success{
                    
                    print("Edit success")
                    
                    //Ejecutar segue de manera sincrona
                    DispatchQueue.global().sync {
                        do{
                            let defaults = UserDefaults.standard
                            
                            let token = defaults.object(forKey: "token")!
                            
                            print ("User token: ",token)
                            
                            let dataToken = defaults.string(forKey: "token")
                            //Segue to contact list view

                        }catch {
                            
                            }
                    }
                    
                }else{
                    
                    print("Request error")
                    //If login fails then show alert
                    spinner.stopAnimating()
                    spinner.isHidden = true
                    self.present(Helper.showAlertController(title: "Failed Request", message: "Code 404"), animated: true, completion: nil)
                
                }
            })
            self.performSegue(withIdentifier: "editToProfile", sender: self)
            spinner.stopAnimating()
            spinner.isHidden = true
            
           }}
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        spinner.isHidden = true
        spinner.stopAnimating()

        //Set circular corners
        BTNEditStyle.layer.cornerRadius = 25.0
        //TFEmail?.layer.borderColor = UIColor(red: 249/255, green: 120/255, blue: 88/225, alpha: 1).cgColor
        TFEmail?.layer.cornerRadius = 10.0
        //TFEmail?.layer.borderWidth = 2
        TFName?.layer.cornerRadius = 10.0
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        spinner.isHidden = true

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    }}
